from __future__ import annotations

import http.client
import json
import inspect
import os
import shutil
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from clawtune_sidecar.contracts.models import ResourceScope, ToolBeforeRequest, ToolCompletedEvent
from clawtune_sidecar.identity import correlation_key, owners_compatible


@dataclass(frozen=True)
class DockerExecRecord:
    exec_id: str
    container_id: str | None
    container_name: str | None
    pid: int | None
    cgroup_path: str | None
    command: str | None
    root_starttime_ticks: int | None
    started_monotonic_s: float
    started_wall_s: float


@dataclass(frozen=True)
class _ActiveTool:
    request: ToolBeforeRequest
    started_monotonic_s: float
    started_wall_s: float


class DockerExecObserver:
    """Infer per-tool scopes from Docker exec events without changing OpenClaw.

    This is intentionally best-effort and explicit: matched scopes are labelled
    ``docker-exec-inferred``; callers should keep a sandbox cgroup fallback for
    events that are too short-lived or not implemented as Docker execs.
    """

    def __init__(
        self,
        *,
        enabled: bool = False,
        docker_socket: str = "/var/run/docker.sock",
        docker_bin: str | None = None,
        container_id: str | None = None,
        container_prefix: str | None = None,
        cgroup_path: str | None = None,
        match_window_s: float = 1.0,
        max_records: int = 2_000,
        on_scope: Callable[..., bool | None] | None = None,
        autostart: bool = True,
    ) -> None:
        self.enabled = enabled
        self.docker_socket = docker_socket
        self.docker_bin = docker_bin or shutil.which("docker")
        self.container_id = _short_container_id(container_id)
        self.container_prefix = container_prefix
        self.cgroup_path = cgroup_path.rstrip("/") if cgroup_path else None
        self.match_window_s = match_window_s
        self.max_records = max_records
        self.on_scope = on_scope
        self._on_scope_accepts_runtime = _callback_accepts_runtime_id(on_scope)
        self._on_scope_accepts_owner = _callback_accepts_keyword(on_scope, "owner")
        self._active: dict[tuple[str | None, ...], _ActiveTool] = {}
        self._matched: dict[tuple[str | None, ...], DockerExecRecord] = {}
        self._records: list[DockerExecRecord] = []
        self._consumed_exec_ids: set[str] = set()
        self._cgroup_baseline: dict[tuple[str | None, ...], set[int]] = {}
        self._cgroup_seen: dict[tuple[str | None, ...], set[int]] = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._cgroup_thread: threading.Thread | None = None
        self._diag: dict[str, Any] = {
            "enabled": enabled,
            "docker_bin_present": self.docker_bin is not None,
            "cgroup_path": self.cgroup_path,
            "events_loop_started": False,
            "event_lines_seen": 0,
            "exec_events_matched_container": 0,
            "inspections_ok": 0,
            "docker_exec_matches": 0,
            "cgroup_diff_baselines": 0,
            "cgroup_diff_captures": 0,
            "last_error": None,
        }
        if self.enabled and autostart and (
            self.docker_bin is not None or self.cgroup_path
        ):
            self.start()

    def start(self) -> None:
        with self._lock:
            if self._thread is None and self.docker_bin is not None:
                self._thread = threading.Thread(
                    target=self._run_events_loop, daemon=True
                )
                self._thread.start()
                self._diag["events_loop_started"] = True
            if self._cgroup_thread is None and self.cgroup_path:
                self._cgroup_thread = threading.Thread(
                    target=self._run_cgroup_poll_loop, daemon=True
                )
                self._cgroup_thread.start()

    def stop(self) -> None:
        self._stop.set()

    def update_cgroup(self, *, cgroup_path: str | None) -> None:
        """Bind a late-discovered sandbox container cgroup for the diff fallback."""
        with self._lock:
            if cgroup_path:
                self.cgroup_path = cgroup_path.rstrip("/")
                self._diag["cgroup_path"] = self.cgroup_path
            if self.enabled and self._cgroup_thread is None and self.cgroup_path:
                self._cgroup_thread = threading.Thread(
                    target=self._run_cgroup_poll_loop, daemon=True
                )
                self._cgroup_thread.start()

    def update_container(self, *, container_id: str | None, container_name: str | None = None) -> None:
        with self._lock:
            if container_id:
                self.container_id = _short_container_id(container_id)
            if container_name and self.container_prefix is None:
                self.container_prefix = container_name

    def update_runtime_scope(
        self,
        owner: ToolBeforeRequest | ToolCompletedEvent | Any,
        scope: ResourceScope,
    ) -> None:
        """Bind a late-discovered container only to matching active tools."""

        with self._lock:
            for key, active in list(self._active.items()):
                if not owners_compatible(active.request, owner):
                    continue
                request = active.request.model_copy(update={"resource_scope": scope})
                self._active[key] = _ActiveTool(
                    request=request,
                    started_monotonic_s=active.started_monotonic_s,
                    started_wall_s=active.started_wall_s,
                )

    def begin_tool(self, request: ToolBeforeRequest) -> None:
        if not self.enabled:
            return
        if request.resource_scope is not None and not _is_shared_runtime_scope(request.resource_scope):
            return
        with self._lock:
            key = correlation_key(request)
            active = _ActiveTool(
                request=request,
                started_monotonic_s=time.monotonic(),
                started_wall_s=time.time(),
            )
            self._active[key] = active
            if self.cgroup_path:
                baseline = _read_cgroup_procs(self.cgroup_path)
                if baseline is not None:
                    self._cgroup_baseline[key] = baseline
                    self._diag["cgroup_diff_baselines"] += 1
            record = self._match_record(active, None)
            if record is not None:
                self._matched[key] = record
                self._consumed_exec_ids.add(record.exec_id)
        self._notify_scope(key, active, record)

    def infer_scope(self, event: ToolCompletedEvent) -> ResourceScope | None:
        if not self.enabled or event.execution_id is not None:
            return None
        if event.resource_scope is not None and not _is_shared_runtime_scope(event.resource_scope):
            return None
        key = correlation_key(event)
        with self._lock:
            active = self._active.pop(key, None)
            if active is None and event.tool_call_id is not None:
                active = self._pop_by_tool_call_id(
                    event.tool_call_id,
                    event.runtime_id,
                    owner=event,
                )
            if active is None:
                active = self._pop_unique_by_tool_name(
                    event.tool_name,
                    event.runtime_id,
                    owner=event,
                )
            if active is None:
                return None
            matched_key = correlation_key(active.request)
            record = self._matched.pop(matched_key, None)
            if record is None:
                record = self._match_record(active, event)
            if record is not None:
                self._consumed_exec_ids.add(record.exec_id)
                self._diag["docker_exec_matches"] += 1
                return _scope_for_record(record)
            # Docker exec events were not observable on this host (OpenClaw may
            # not run each native tool as a separate ``docker exec``, or the
            # events/socket are unavailable).  Fall back to the sandbox
            # container cgroup: pids that newly appeared in its ``cgroup.procs``
            # during the tool window are this tool's own processes, so read/
            # edit get per-PID attribution instead of the whole container.
            scope = self._scope_from_cgroup_diff(matched_key, active)
            if scope is not None:
                self._diag["cgroup_diff_captures"] += 1
            return scope

    def record_exec_start(
        self,
        *,
        exec_id: str,
        container_id: str | None,
        container_name: str | None = None,
        pid: int | None = None,
        cgroup_path: str | None = None,
        command: str | None = None,
        started_monotonic_s: float | None = None,
        started_wall_s: float | None = None,
    ) -> None:
        if not self._container_matches(container_id, container_name):
            return
        if pid is not None and cgroup_path is None:
            cgroup_path = _read_host_cgroup_path(pid)
        record = DockerExecRecord(
            exec_id=exec_id,
            container_id=_short_container_id(container_id),
            container_name=container_name,
            pid=pid,
            cgroup_path=cgroup_path,
            command=command,
            root_starttime_ticks=_read_pid_starttime_ticks(pid),
            started_monotonic_s=started_monotonic_s if started_monotonic_s is not None else time.monotonic(),
            started_wall_s=started_wall_s if started_wall_s is not None else time.time(),
        )
        notification: tuple[tuple[str | None, ...], _ActiveTool, DockerExecRecord] | None = None
        with self._lock:
            if any(
                existing.exec_id == exec_id and existing.pid is not None
                for existing in self._records
            ):
                return
            self._records.append(record)
            if len(self._records) > self.max_records:
                del self._records[: len(self._records) - self.max_records]
            if record.pid is not None:
                notification = self._match_active_for_record(record)
        if notification is not None:
            self._notify_scope(*notification)

    def _match_record(
        self,
        active: _ActiveTool,
        event: ToolCompletedEvent | None,
    ) -> DockerExecRecord | None:
        ended = time.monotonic()
        candidates = [
            record
            for record in self._records
            if record.exec_id not in self._consumed_exec_ids
            and record.pid is not None
            and active.started_monotonic_s - 0.25 <= record.started_monotonic_s <= ended + self.match_window_s
            and self._record_matches_active(record, active)
        ]
        if not candidates:
            return None
        tool_rank = _tool_command_rank(
            event.tool_name if event is not None else active.request.tool_name
        )
        candidates.sort(
            key=lambda record: (
                tool_rank(record.command),
                abs(record.started_monotonic_s - active.started_monotonic_s),
            )
        )
        return candidates[0]

    def _match_active_for_record(
        self,
        record: DockerExecRecord,
    ) -> tuple[tuple[str | None, ...], _ActiveTool, DockerExecRecord] | None:
        if record.exec_id in self._consumed_exec_ids:
            return None
        candidates = [
            (key, active)
            for key, active in self._active.items()
            if key not in self._matched
            and self._record_matches_active(record, active)
            and active.started_monotonic_s - 0.25
            <= record.started_monotonic_s
            <= time.monotonic() + self.match_window_s
        ]
        if not candidates:
            return None
        candidates.sort(
            key=lambda item: (
                _tool_command_rank(item[1].request.tool_name)(record.command),
                abs(record.started_monotonic_s - item[1].started_monotonic_s),
            )
        )
        key, active = candidates[0]
        self._matched[key] = record
        self._consumed_exec_ids.add(record.exec_id)
        return key, active, record

    def _notify_scope(
        self,
        key: tuple[str | None, ...],
        active: _ActiveTool,
        record: DockerExecRecord | None,
    ) -> None:
        if record is None or self.on_scope is None:
            return
        scope = _scope_for_record(record)
        if scope is not None:
            kwargs: dict[str, Any] = {}
            if self._on_scope_accepts_runtime:
                kwargs["runtime_id"] = active.request.runtime_id
            if self._on_scope_accepts_owner:
                kwargs["owner"] = active.request
            bound = self.on_scope(active.request.tool_call_id, scope, **kwargs)
            if bound is False:
                # The process exited before the sampler could take a PID
                # baseline.  Keep the shared fallback and do not later relabel
                # those samples as exact PID attribution.
                with self._lock:
                    self._matched.pop(key, None)

    def _container_matches(self, container_id: str | None, container_name: str | None) -> bool:
        short = _short_container_id(container_id)
        if self.container_id and short:
            # The exact-id branch is the strongest signal; when it does not
            # match, fall through to the prefix/global rules instead of
            # dropping the event (the configured id may be a stale snapshot
            # while the runtime-discovered prefix is still correct).
            if short.startswith(self.container_id) or self.container_id.startswith(short):
                return True
        if self.container_prefix and container_name:
            return container_name.startswith(self.container_prefix)
        return self.container_id is None and self.container_prefix is None

    def _record_matches_active(
        self,
        record: DockerExecRecord,
        active: _ActiveTool,
    ) -> bool:
        scope = active.request.resource_scope
        if scope is not None and scope.container_id:
            expected = _short_container_id(scope.container_id)
            actual = _short_container_id(record.container_id)
            return bool(
                expected
                and actual
                and (actual.startswith(expected) or expected.startswith(actual))
            )
        # A scoped runtime without an exact container is not eligible for
        # time-nearest matching against arbitrary host Docker events.
        if active.request.runtime_id is not None:
            return False
        return self._container_matches(record.container_id, record.container_name)

    def _pop_by_tool_call_id(
        self,
        tool_call_id: str,
        runtime_id: str | None,
        *,
        owner: ToolCompletedEvent | None = None,
    ) -> _ActiveTool | None:
        for key, active in list(self._active.items()):
            if (
                active.request.tool_call_id == tool_call_id
                and active.request.runtime_id == runtime_id
                and (owner is None or owners_compatible(active.request, owner))
            ):
                self._active.pop(key, None)
                return active
        return None

    def _pop_unique_by_tool_name(
        self,
        tool_name: str,
        runtime_id: str | None,
        *,
        owner: ToolCompletedEvent | None = None,
    ) -> _ActiveTool | None:
        matches = [
            (key, active)
            for key, active in self._active.items()
            if active.request.tool_name == tool_name
            and active.request.runtime_id == runtime_id
            and (owner is None or owners_compatible(active.request, owner))
        ]
        if len(matches) != 1:
            return None
        key, active = matches[0]
        self._active.pop(key, None)
        return active

    def _scope_from_cgroup_diff(
        self,
        key: tuple[str | None, ...],
        active: _ActiveTool,
    ) -> ResourceScope | None:
        """Per-PID scope from pids newly seen in the sandbox cgroup window."""
        baseline = self._cgroup_baseline.pop(key, None)
        seen = self._cgroup_seen.pop(key, None)
        if not seen:
            return None
        root_pid = min(seen)
        container_id = None
        scope = active.request.resource_scope
        if scope is not None and scope.container_id:
            container_id = scope.container_id
        return ResourceScope(
            kind="pid",
            execution_id=None,
            pid=root_pid,
            root_pid=root_pid,
            root_starttime_ticks=_read_pid_starttime_ticks(root_pid),
            cgroup_path=None,
            container_id=container_id,
            include_children=True,
            source="docker-cgroup-diff",
            attribution_source="docker-exec-pid",
        )

    def _run_cgroup_poll_loop(self) -> None:
        """Sample the sandbox container cgroup and record newly-appeared pids
        for each active tool (captures short-lived read/edit processes)."""
        while not self._stop.is_set():
            self._poll_cgroup_once()
            self._stop.wait(0.02)

    def _poll_cgroup_once(self) -> None:
        """One cgroup.procs sample: union newly-appeared pids for active tools."""
        path = self.cgroup_path
        if not path:
            return
        procs = _read_cgroup_procs(path)
        if procs is None:
            return
        with self._lock:
            for key, baseline in list(self._cgroup_baseline.items()):
                seen = self._cgroup_seen.setdefault(key, set())
                for pid in procs:
                    if pid not in baseline:
                        seen.add(pid)

    def diagnostics(self) -> dict[str, Any]:
        with self._lock:
            return {"docker_bin": self.docker_bin, "cgroup_path": self.cgroup_path, **self._diag}

    def _run_events_loop(self) -> None:
        if self.docker_bin is None:
            return
        while not self._stop.is_set():
            process = subprocess.Popen(
                _docker_events_command(self.docker_bin),
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            try:
                if process.stdout is None:
                    return
                for line in process.stdout:
                    if self._stop.is_set():
                        break
                    self._handle_event_line(line)
            finally:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
            self._stop.wait(1.0)

    def _handle_event_line(self, line: str) -> None:
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            return
        actor = event.get("Actor") if isinstance(event.get("Actor"), dict) else {}
        attrs = actor.get("Attributes") if isinstance(actor.get("Attributes"), dict) else {}
        exec_id = _as_str(attrs.get("execID")) or _as_str(attrs.get("execId"))
        if not exec_id:
            return
        container_id = (
            _as_str(attrs.get("container"))
            or _as_str(attrs.get("containerID"))
            or _as_str(actor.get("ID"))
            or _as_str(event.get("id"))
        )
        container_name = _as_str(attrs.get("name"))
        if not self._container_matches(container_id, container_name):
            return
        info = self._inspect_exec(exec_id)
        if info is None or _optional_int(info.get("Pid")) in {None, 0}:
            threading.Thread(
                target=self._inspect_exec_until_started,
                kwargs={
                    "exec_id": exec_id,
                    "container_id": container_id,
                    "container_name": container_name,
                },
                daemon=True,
            ).start()
            return
        pid = _optional_int(info.get("Pid")) if info else None
        if container_id is None and info:
            container_id = _as_str(info.get("ContainerID"))
        command = _exec_command(info)
        self.record_exec_start(
            exec_id=exec_id,
            container_id=container_id,
            container_name=container_name,
            pid=pid,
            command=command,
        )

    def _inspect_exec_until_started(
        self,
        *,
        exec_id: str,
        container_id: str | None,
        container_name: str | None,
    ) -> None:
        # exec_create precedes exec_start.  A short high-frequency watcher
        # catches PIDs for native file tools that may exit before an
        # exec_start-only subscriber can inspect them.
        deadline = time.monotonic() + 1.0
        while not self._stop.is_set() and time.monotonic() < deadline:
            info = self._inspect_exec(exec_id)
            if info is None:
                return
            pid = _optional_int(info.get("Pid"))
            if pid not in {None, 0}:
                self.record_exec_start(
                    exec_id=exec_id,
                    container_id=container_id or _as_str(info.get("ContainerID")),
                    container_name=container_name,
                    pid=pid,
                    command=_exec_command(info),
                )
                return
            time.sleep(0.005)

    def _inspect_exec(self, exec_id: str) -> dict[str, Any] | None:
        if not os.path.exists(self.docker_socket):
            return None
        try:
            conn = _UnixHTTPConnection(self.docker_socket, timeout=0.5)
            conn.request("GET", f"/exec/{exec_id}/json")
            response = conn.getresponse()
            body = response.read()
            conn.close()
        except OSError:
            return None
        if response.status != 200:
            return None
        try:
            parsed = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None
        return parsed if isinstance(parsed, dict) else None


class _UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, socket_path: str, timeout: float) -> None:
        super().__init__("localhost", timeout=timeout)
        self.socket_path = socket_path

    def connect(self) -> None:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        sock.connect(self.socket_path)
        self.sock = sock


def _docker_events_command(docker_bin: str) -> list[str]:
    return [
        docker_bin,
        "events",
        "--format",
        "{{json .}}",
        "--filter",
        "type=container",
        "--filter",
        "event=exec_create",
        "--filter",
        "event=exec_start",
    ]


def _exec_command(info: dict[str, Any] | None) -> str | None:
    if not info:
        return None
    config = info.get("ProcessConfig")
    if not isinstance(config, dict):
        return None
    parts: list[str] = []
    entrypoint = config.get("entrypoint")
    if isinstance(entrypoint, str) and entrypoint:
        parts.append(entrypoint)
    args = config.get("arguments")
    if isinstance(args, list):
        parts.extend(str(item) for item in args)
    elif isinstance(args, str) and args:
        parts.append(args)
    return " ".join(parts) if parts else None


def _tool_command_rank(tool_name: str):
    needles = {
        "exec": ("clawtune-launch", "/bin/sh", "sh -c", "bash -lc"),
        "read": ("openclaw-sandbox-fs", "readlink", "cat ", "sed "),
        "write": ("openclaw-sandbox-fs", "python3", "mv "),
        "edit": ("openclaw-sandbox-fs", "python3", "patch"),
        "apply_patch": ("openclaw-sandbox-fs", "python3", "patch"),
        "process": ("ps ", "kill", "tail", "openclaw"),
    }.get(tool_name, ())

    def rank(command: str | None) -> int:
        if not command:
            return 10
        lowered = command.lower()
        for idx, needle in enumerate(needles):
            if needle in lowered:
                return idx
        return 5

    return rank


def _read_cgroup_procs(cgroup_path: str) -> set[int] | None:
    """Read a cgroup-v2 ``cgroup.procs`` into a set of host pids."""
    try:
        text = Path(cgroup_path, "cgroup.procs").read_text(encoding="utf-8")
    except OSError:
        return None
    pids: set[int] = set()
    for raw in text.split():
        try:
            pid = int(raw)
        except ValueError:
            continue
        if pid > 0:
            pids.add(pid)
    return pids


def _read_host_cgroup_path(pid: int) -> str | None:
    try:
        text = Path(f"/proc/{pid}/cgroup").read_text(encoding="utf-8")
    except OSError:
        return None
    for line in text.splitlines():
        if not line.startswith("0::"):
            continue
        path = line[3:]
        if not path or path == "/":
            return "/sys/fs/cgroup"
        return f"/sys/fs/cgroup{path}"
    return None


def _read_pid_starttime_ticks(pid: int | None) -> int | None:
    if pid is None:
        return None
    try:
        fields = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8").split()
        return int(fields[21])
    except (OSError, ValueError, IndexError):
        return None


def _scope_for_record(record: DockerExecRecord) -> ResourceScope | None:
    if record.pid is None:
        return None
    # Docker exec children share the container cgroup, so sampling that cgroup
    # is not per-tool attribution.  The event PID is the honest isolation unit;
    # include descendants and retain the cgroup only in the observer record for
    # diagnostics.
    return ResourceScope(
        kind="pid",
        execution_id=None,
        pid=record.pid,
        root_pid=record.pid,
        root_starttime_ticks=record.root_starttime_ticks,
        cgroup_path=None,
        container_id=record.container_id,
        include_children=True,
        source="docker-events",
        attribution_source="docker-exec-pid",
    )


def _callback_accepts_runtime_id(callback: Callable[..., Any] | None) -> bool:
    return _callback_accepts_keyword(callback, "runtime_id")


def _callback_accepts_keyword(
    callback: Callable[..., Any] | None,
    name: str,
) -> bool:
    if callback is None:
        return False
    try:
        parameters = inspect.signature(callback).parameters.values()
    except (TypeError, ValueError):
        return False
    return any(
        parameter.name == name
        or parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in parameters
    )


def _is_shared_runtime_scope(scope: ResourceScope) -> bool:
    return (
        scope.source in {"openclaw-runtime", "openclaw-sandbox"}
        or scope.attribution_source
        in {"shared-runtime-process", "shared-sandbox-container"}
    )


def _short_container_id(value: str | None) -> str | None:
    if not value:
        return None
    return value.strip().lstrip("/")[:12]


def _as_str(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _optional_int(value: Any) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= 0 else None
